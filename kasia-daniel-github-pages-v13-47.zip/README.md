# Kasia & Daniel — 09.05.2027

Statyczna wersja strony przygotowana pod GitHub Pages.

## Publikacja
1. Utwórz nowe repozytorium na GitHubie.
2. Wgraj całą zawartość tego folderu do głównego katalogu repozytorium.
3. Wejdź w Settings → Pages.
4. W sekcji Build and deployment wybierz Source: Deploy from a branch.
5. Wybierz branch `main` i folder `/ (root)`, a następnie Save.
6. Po chwili GitHub pokaże publiczny adres strony.

Plik startowy: `index.html`.
